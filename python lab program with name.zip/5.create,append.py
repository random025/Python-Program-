#5. Write a program to create, append, and remove lists in python

pets = ['cat', 'dog', 'rat', 'pig', 'tiger']
snakes=['python','anaconda','fish','cobra','mamba']
print("Pets are :",pets)
print("Snakes are :",snakes)
animals=pets+snakes
print("Animals are :",animals)
snakes.remove("fish")
print("updated Snakes are :",snakes)
