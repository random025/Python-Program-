#20)  Write a python program to define a module and import a specific function in that module to another program 
#20.py sub program
# arth.py
''' Arithmetic Operations Module with Multiple functions'''
def Add(a,b):
    c=a+b
    return c
def Sub(a,b):
    c=a-b
    return c
def Mul(a,b):
    c=a*b
    return c

