#3. Write a program to create, concatenate and print a string and accessing sub-string from a given string.
s1=input("Enter first String : ")
s2=input("Enter second String : ")
print("First string is : ",s1)
print("Second string is : ",s2)
print("concatenations of two strings :",s1+s2)
print("Substring of given string :",s1[1:4])
