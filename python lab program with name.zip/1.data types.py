#1.Write a program to demonstrate different number data types in Python.
a=10; 					#Integer Data type
b=11.5; 				#Float Data type
c=2.05j; 				#Complex Number
print("a is Type of",type(a)); 		#prints type of variable a
print("b is Type of",type(b)); 		#prints type of variable b
print("c is Type of",type(c)); 		#prints type of variable c
