#6. Write a program to demonstrate working with tuples in python 

# creating tuples with college names.. 
colleges = ("SIIET","BHARAT","GNIT", "AVN") 
print("the lists in colleges tuple is",colleges) 
print("we can\'t add or remove new elements in a tuple") 
print("length of the tuple colleges is:",len(colleges)) 
# checking whether 'SIIET' is present in the tuple or not 
if "SIIET" in colleges: 
     print("Yes, 'SIIET' is in the colleges tuple")
