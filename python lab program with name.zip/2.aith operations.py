#2.Write a program to perform different Arithmetic Operations on numbers in Python.
a=int(input("Enter a value")); 	#input() takes data from console at runtime as string.
b=int(input("Enter b value")); 	#typecast the input string to int.
print("Addition of a and b ",a+b);
print("Subtraction of a and b ",a-b);
print("Multiplication of a and b ",a*b);
print("Division of a and b ",a/b);
print("Remainder of a and b ",a%b);
print("Exponent of a and b ",a**b); 		#exponent operator (a^b)
print("Floar division of a and b ",a//b); 	# floar division
